from datetime import date
   a=date(2014, 7, 2)
   b=date(2014, 7, 11)
   print(b-a)
