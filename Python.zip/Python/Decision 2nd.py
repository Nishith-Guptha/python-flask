 a=int(input())
   if(a%2!=0):
      print("odd")
   else:
      print("even")