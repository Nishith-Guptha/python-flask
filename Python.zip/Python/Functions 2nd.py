 x=int(input())
    y=int(input())
    def di(x,y):
    	d= (x + y) * (x + y)
    	return d
    k=di(x,y)
    print(k)