def addition(a,b):
    return f"Sum of {a} and {b} is {a+b}"

def subtraction(a,b):
    return f"Subtraction of {a} and {b} is {a-b}"

def mul_div(a,b):
    return f"Multiply of {a} and {b} is {a*b} \nDivision of {a} and {b} is {a/b}"