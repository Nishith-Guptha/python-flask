import math
import own_module

print(math.sin(90))

print(my_module.addition(40,20))
print(my_module.subtraction(40,20))
print(my_module.mul_div(40,20))