pi=3.14
   raduis=float(input("enter radius"))
   area=pi*raduis*raduis
   print(area)