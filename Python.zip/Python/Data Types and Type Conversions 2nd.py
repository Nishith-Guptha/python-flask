 l=list(map(int,input().strip().split()))
   a=max(l)
   print(a)