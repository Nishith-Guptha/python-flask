a=input()
   if a[0:2] == "ls":
      print(a)
   else:
       a=str(a)
       print("ls"+a)