a=list(map(int,input().strip().split()))
    res="".join(str(i) for i in a)
    print(res)