with open('file.txt','r+') as f:
    f.seek(len(f.read())+5)

    f.write("\nRitik, Nanwani, Acropolis, Indore\n")
    f.write("Pawan, Bajaj, LNCT, Bhopal\n")
    print("Data Append Successfully")
f.close()
