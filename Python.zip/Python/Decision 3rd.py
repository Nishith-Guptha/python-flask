a=input()
   a=a.lower()
   l=["a","e","i","o","u"]
   if a in l:
    	print("Vowel")
   else:
    	print("Not a Vowel")