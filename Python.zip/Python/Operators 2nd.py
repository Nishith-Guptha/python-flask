n=int(input())
   a=f"{n}"*2
   b=f"{n}"*3
   a=int(a)
   b=int(b)
   print(n+a+b)