i=input()
if len(i)<2:
    print("String")
else:
    a=i[0:2]
    b=i[len(i)-2:]
    c=a+b
    print(c)