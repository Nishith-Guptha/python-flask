from decimal import DivisionByZero  
def divide_by_zero():  # One = DivisionByZero
    try:
        print(10/0)
    except DivisionByZero as error:
        print(error)

# divide_by_zero()



def type_error():  # Second : TypeError
    try:
        a=5
        b='0'
        print(a+b)
    except TypeError as error:
        print("Type Error, cannot integer with string")

type_error()



def value_error():  # Third : ValueError
    x = 0
    try:
        x=int(input('Enter a number upto 100: '))

    except ValueError:
        print("ValueError : x should be integer")

# value_error()



def index_error():  # Fourth : IndexError
    try:
        arr = [5,7,2,3,1,10]
        print( arr[7] )
    except IndexError as error:
        print("IndexError : list index out of range")

# index_error()



def name_error():  # Fifth : NameError
    try:
        s = "hello world"
        print(s2)
    except NameError as error:
        print("NameError : name s2 is not defined")

# name_error()