def gcd(a, b):
   gcd = 1   
   if a % b == 0:
       return y   
   for k in range(int(b / 2), 0, -1):
       if a % k == 0 and b % k == 0:
           gcd = k
           break 
   return gcd

n1 = int(input("Enter first number : "))
n2 = int(input("Enter second number : "))
print(f"GCD of {n1} and {n2} =",gcd(n1, n2))