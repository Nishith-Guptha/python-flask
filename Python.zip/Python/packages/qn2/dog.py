def food():
    return "dog eat dairy products and drink milk"

def speciality():
    return "Dogs are Omnivorous"