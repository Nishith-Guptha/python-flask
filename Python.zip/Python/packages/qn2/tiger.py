
def food():
    return "Tiger eat flesh and drink water"

def speciality():
    return "tigers are Carnivorous"