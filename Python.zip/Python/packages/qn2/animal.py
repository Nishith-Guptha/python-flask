import tiger 
import monkey 
import dog

print(dog.food())
print(dog.speciality())
print('\n')

print(tiger.food())
print(tiger.speciality())
print('\n')

print(monkey.food())
print(monkey.speciality())
