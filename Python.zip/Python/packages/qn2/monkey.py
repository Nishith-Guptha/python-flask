
def food():
    return "Dog eat peanuts and drink water"

def speciality():
    return "tigers are omnivores"